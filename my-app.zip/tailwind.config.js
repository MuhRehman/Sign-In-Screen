/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{html,js}"],
  content: [],
  theme: {
    extend: {},
  },
  plugins: [],
}

